package com.kajidevworks.kajitraslate

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

/**
 * MainActivity presents a simple welcome screen with a single button to start a call.
 * In a real application this could be replaced by a contact list or meeting scheduler.
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnStart: Button = findViewById(R.id.btn_start)
        btnStart.setOnClickListener {
            // Launch the call activity. In a full implementation this would require
            // negotiating a WebRTC or VoIP call session with a remote peer.
            val intent = Intent(this, CallActivity::class.java)
            startActivity(intent)
        }
    }
}