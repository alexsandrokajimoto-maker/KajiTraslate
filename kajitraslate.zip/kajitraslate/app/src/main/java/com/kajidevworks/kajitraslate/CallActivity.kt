package com.kajidevworks.kajitraslate

import android.Manifest
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.util.Locale

/**
 * CallActivity demonstrates a simple audio translation pipeline. It uses the native
 * Android SpeechRecognizer to transcribe speech, calls LibreTranslate (a free
 * translation service) to translate the text, and then plays the translation
 * using Android's TextToSpeech. The translation runs continuously until stopped.
 */
class CallActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var recognizerIntent: android.content.Intent
    private lateinit var tts: TextToSpeech

    private lateinit var spinnerSource: Spinner
    private lateinit var spinnerTarget: Spinner
    private lateinit var textTranscription: TextView
    private lateinit var textTranslation: TextView
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    private var isListening = false

    // Supported languages for translation. The keys are display names and values are ISO codes
    private val languages = mapOf(
        "English" to "en",
        "Chinese" to "zh",
        "Hindi" to "hi",
        "Spanish" to "es",
        "French" to "fr",
        "Arabic" to "ar",
        "Bengali" to "bn",
        "Portuguese" to "pt",
        "Russian" to "ru",
        "Urdu" to "ur"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_call)

        // Request microphone permission at runtime
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 0)

        spinnerSource = findViewById(R.id.spinnerSource)
        spinnerTarget = findViewById(R.id.spinnerTarget)
        textTranscription = findViewById(R.id.textTranscription)
        textTranslation = findViewById(R.id.textTranslation)
        btnStart = findViewById(R.id.btnStartTranslation)
        btnStop = findViewById(R.id.btnStopTranslation)

        // Set up spinners with language names
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, languages.keys.toList())
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerSource.adapter = adapter
        spinnerTarget.adapter = adapter

        // Initialize text‑to‑speech engine
        tts = TextToSpeech(this, this)

        // Initialize speech recognizer and intent
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizerIntent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        }

        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                // If an error occurs while listening, restart listening if still active
                if (isListening) {
                    speechRecognizer.cancel()
                    speechRecognizer.startListening(recognizerIntent)
                }
            }

            override fun onResults(results: Bundle) {
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val spokenText = matches[0]
                    textTranscription.text = spokenText
                    // Perform translation asynchronously
                    translateAndSpeak(spokenText)
                }
                if (isListening) {
                    // Continue listening for more speech
                    speechRecognizer.startListening(recognizerIntent)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        btnStart.setOnClickListener {
            if (!isListening) {
                startListening()
            }
        }

        btnStop.setOnClickListener {
            stopListening()
        }
    }

    /** Starts continuous speech recognition */
    private fun startListening() {
        isListening = true
        speechRecognizer.startListening(recognizerIntent)
    }

    /** Stops speech recognition */
    private fun stopListening() {
        isListening = false
        speechRecognizer.stopListening()
    }

    /** Handles translation and TTS on a background thread */
    private fun translateAndSpeak(text: String) {
        val sourceLangCode = languages[spinnerSource.selectedItem.toString()] ?: "en"
        val targetLangCode = languages[spinnerTarget.selectedItem.toString()] ?: "en"
        lifecycleScope.launch {
            val translation = translateText(text, sourceLangCode, targetLangCode)
            textTranslation.text = translation
            speakText(translation, targetLangCode)
        }
    }

    /** Performs the HTTP request to LibreTranslate. */
    private suspend fun translateText(text: String, source: String, target: String): String {
        return withContext(Dispatchers.IO) {
            try {
                val url = "https://libretranslate.de/translate"
                val params = "q=" + java.net.URLEncoder.encode(text, "UTF-8") +
                        "&source=" + source +
                        "&target=" + target +
                        "&format=text"
                val response = URL("$url?$params").readText()
                val json = JSONObject(response)
                json.getString("translatedText")
            } catch (e: Exception) {
                e.printStackTrace()
                "Translation error"
            }
        }
    }

    /** Speaks the given text aloud using the TextToSpeech engine. */
    private fun speakText(text: String, langCode: String) {
        val locale = Locale.forLanguageTag(langCode)
        tts.language = locale
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    override fun onInit(status: Int) {
        // The TTS engine is ready. We could set a default language here if desired.
    }

    override fun onDestroy() {
        super.onDestroy()
        // Release resources when activity is destroyed
        speechRecognizer.destroy()
        tts.shutdown()
    }
}